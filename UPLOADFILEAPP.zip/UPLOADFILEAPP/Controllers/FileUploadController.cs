﻿using Microsoft.AspNetCore.Mvc;
using UPLOADFILEAPP.Data;
using UPLOADFILEAPP.Models;

namespace UPLOADFILEAPP.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FileUploadController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public FileUploadController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        [HttpPost("upload")]
        [RequestSizeLimit(20 * 1024 * 1024)] // 20 MB
        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("File not selected.");

            var allowedTypes = new[] { ".pdf", ".docx", ".png", ".jpg", ".jpeg" };
            var ext = Path.GetExtension(file.FileName).ToLower();

            if (!allowedTypes.Contains(ext))
                return BadRequest("File type not allowed.");

            var uploadsFolder = Path.Combine(_env.ContentRootPath, "UploadedFiles");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            var filePath = Path.Combine(uploadsFolder, file.FileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            var record = new FileRecord
            {
                FileName = file.FileName,
                FilePath = filePath,
                FileSize = Math.Round(file.Length / 1024.0 / 1024.0, 2),
                UploadedBy = "TestUser", // You can replace this later with auth
                UploadedAt = DateTime.Now
            };

            _context.Files.Add(record);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Uploaded successfully", record });
        }

        [HttpGet("all")]
        public IActionResult GetAllFiles()
        {
            var files = _context.Files.OrderByDescending(f => f.UploadedAt).ToList();
            return Ok(files);
        }

        [HttpGet("download/{id}")]
        public IActionResult DownloadFile(int id)
        {
            var file = _context.Files.FirstOrDefault(f => f.Id == id);
            if (file == null) return NotFound();

            var bytes = System.IO.File.ReadAllBytes(file.FilePath);
            return File(bytes, "application/octet-stream", file.FileName);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFile(int id)
        {
            var file = _context.Files.FirstOrDefault(f => f.Id == id);
            if (file == null) return NotFound();

            if (System.IO.File.Exists(file.FilePath))
                System.IO.File.Delete(file.FilePath);

            _context.Files.Remove(file);
            await _context.SaveChangesAsync();

            return Ok(new { message = "File deleted" });
        }
    }
}
