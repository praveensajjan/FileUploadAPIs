﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using UPLOADFILEAPP.Models;

namespace UPLOADFILEAPP.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }

        public DbSet<FileRecord> Files { get; set; }
    }
}
